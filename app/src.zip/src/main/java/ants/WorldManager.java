package ants;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.Queue;

/**
 * WorldManager
 */

public class WorldManager {
    private final Map map;
    private BlockingQueue<Ant> ants;
    private Gui gui;
    private WorldConfig config;
    private AntThread[] antThreads;

    public WorldManager(WorldConfig config) {
        this.map = Map.generateRandomMap(config.vertexNumber,
                config.stoneProbability,
                config.leafProbability,
                config.width,
                config.height);

        SoldierAnt tempRedAnt = new SoldierAnt("redi", 2, 5, map.getRedAnthill());
        WorkerAnt tempBlueAnt = new WorkerAnt("bluei", 2, 5, map.getBlueAnthill());

        this.config = config;
        this.ants = new ArrayBlockingQueue<Ant>(config.maxRedAnts + config.maxBlueAnts);

        this.ants.add(tempRedAnt);
        this.ants.add(tempBlueAnt);
        this.antThreads = new AntThread[config.maxRedAnts + config.maxBlueAnts];

        this.antThreads[0] = new AntThread(tempRedAnt);
        this.antThreads[1] = new AntThread(tempBlueAnt);
    }

    public void run() {
        this.gui = new Gui(this.config.width, this.config.height);
        for (Ant ant : this.ants) {
            this.gui.addUpdatableSprite(new AntGui(ant));
        }

        for (Vertex v : this.map.getVertices()) {
            System.out.println("Adding vertex at position: " + v.getX() + " " + v.getY());
            this.gui.addStaticSprite(new VertexGui(v));
        }

        this.gui.addStaticSprite(new AnthillGui(this.map.getRedAnthill()));
        this.gui.addStaticSprite(new AnthillGui(this.map.getBlueAnthill()));

        // for (int i = 0; i < this.antThreads.length; i++) {
        for (int i = 0; i < 2; i++) {
            this.antThreads[i].start();
        }

        while (true) {
            gui.update();
            // System.out.println("update");
        }

    }

}
