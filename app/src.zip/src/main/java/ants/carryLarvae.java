package ants;

/**
 * picksLarve
 */
public interface carryLarvae {
    public int getNumberOfLarvaes();

    void pickLarve();

    void dropLarve();
}
