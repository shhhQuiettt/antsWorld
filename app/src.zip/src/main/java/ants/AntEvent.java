// // package ants;

// /**
//  * AntEvent
//  */

// enum AntEvent {
    
// }
// public abstract class AntEvent {

// }
