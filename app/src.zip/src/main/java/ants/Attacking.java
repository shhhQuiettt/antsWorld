package ants;

/**
 * Attacking
 */
public interface Attacking {
    public void attack(Ant ant);
}
