// package ants;

// // /**
// //  * MapVertex
// //  */
// public class MapVertex extends Vertex{
//     private boolean isLeaf;
//     private boolean isStone;

//     public MapVertex(int x, int y, boolean isLeaf, boolean isStone) {
//         super(x, y);
//         this.isLeaf = isLeaf;
//         this.isStone = isStone;
//         System.out.println(this.getX());
//     }
// }
